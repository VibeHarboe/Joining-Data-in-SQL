# sql folder

Denne mappe indeholder filer relateret til sql.