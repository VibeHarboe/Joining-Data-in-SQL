# 🔗 Joining Data in SQL

## 🧠 Projektbeskrivelse

Dette projekt dokumenterer min gennemgang af DataCamp-kurset *Joining Data in SQL*.  
Formålet var at lære at koble relationelle datasæt og hente meningsfuld indsigt ved hjælp af SQL-joins.

Kurset omfattede praktisk arbejde med at kombinere tabeller via forskellige typer joins og håndtere manglende eller uoverensstemmende data.

## 🧰 Nøglefærdigheder

- SQL joins: `INNER`, `LEFT`, `RIGHT`, `FULL`
- `SELF JOIN` og `CROSS JOIN`
- Analyse på tværs af flere tabeller
- Relationel dataintegration
- Fejlhåndtering ved mismatch og NULLs

## 📁 Projektstruktur

```
sql/            → Mine SQL-queries med JOIN-eksempler  
data/           → Eksempeldata (hvis muligt at dele)  
docs/           → Noter og refleksioner fra kurset  
visuals/        → Skærmbilleder fra DataCamp eller resultater  
certificate.pdf → Kursusbevis fra DataCamp  
```

## 📄 Certifikat

🔗 Se kursusbevis: (uploades separat)

## 📚 Ressourcer

- [DataCamp: Joining Data in SQL](https://www.datacamp.com/courses/joining-data-in-sql)

---

Dette projekt er en del af min datakarriereudvikling og dokumenterer praktisk erfaring med relationelle databaser og SQL-forespørgsler.
