# visuals folder

Denne mappe indeholder filer relateret til visuals.